import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ContractService } from '../contract.service';
import { Router } from '@angular/router';
import { Contract } from '../models/contract';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['../../../node_modules/bootstrap/dist/css/bootstrap.min.css', './form.component.css']
})
export class FormComponent implements OnInit {

  get firstName() {
    return this.contractForm.get('firstName');
  }

  get lastName() {
    return this.contractForm.get('lastName');
  }

  get price() {
    return this.contractForm.get('price');
  }


  contract: Contract = null;
  contractForm = null;

  constructor(private contractService: ContractService, private formBuilder: FormBuilder, private route: ActivatedRoute) {
    if (this.route.params['id']) {
      this.contract = contractService.get(this.route.params['id']);
    } else {
      this.contract = contractService.getNew();
    }
    this.contractForm = this.formBuilder.group({
      firstName: [this.contract.firstName, [Validators.required, Validators.minLength(2)]],
      lastName: [this.contract.lastName, [Validators.required, Validators.minLength(2)]],
      price: [this.contract.price, [Validators.required]],
    })
  }

  save() {
    this.contract.firstName = this.contractForm.get('firstName').value;
    this.contract.lastName = this.contractForm.get('lastName').value;
    this.contract.price = this.contractForm.get('price').value;
    this.contractService.cache(this.contract);
  }



  ngOnInit() {

  }
}


