import { Injectable } from '@angular/core';
import { Contract } from './models/contract'

@Injectable(
  { providedIn: 'root', }
)
export class ContractService {
  private contract: Contract;


  constructor() {
  }

  cache(data: Contract) {
    //Add contract data temporarily
    this.contract = data;

  }
  save(data: Contract) {
    //Call dynamoDB API to save contract data.

  }

  get(id: string) {
    //Future: Call the API to get the object.
    return this.contract;
  }

  getNew() {
    return new Contract();
  }
}



