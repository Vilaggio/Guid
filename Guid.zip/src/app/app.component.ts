import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  review: boolean = false;
  formData: any = {
    firstName: '',
    lastName: ''
  };

  displayFormData(data) {
    if (data.firstName && data.lastName) {
      this.formData.firstName = data.firstName;
      this.formData.lastName = data.lastName;
      this.review = true;
    } else {
      alert('Please fill out form!');
    }
  }
  edit() {
    this.review = false;
  }
}
