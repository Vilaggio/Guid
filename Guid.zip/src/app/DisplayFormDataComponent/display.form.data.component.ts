import { Component } from '@angular/core';
import { ContractService } from '../contract.service';
import { Contract } from '../models/contract';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'display-form-data',
  templateUrl: './display.form.data.component.html',
  styleUrls: ['../../../node_modules/bootstrap/dist/css/bootstrap.min.css']
})

export class DisplayFormDataComponent {

  contract: Contract;

  constructor(private contractService: ContractService, private route: ActivatedRoute) {
    this.contract = contractService.get(this.route.params['id']);
    console.log(this.contract);
  }


  ngOnInit() {
    // this.contractService.share.subscribe(firstName => this.firstName = firstName);
    // this.contractService.share.subscribe(lastName => this.lastName = lastName);

  }
}
