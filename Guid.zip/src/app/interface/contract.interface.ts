export interface Contract {
  firstName: string,
  lastName: string,
  price: string,
}