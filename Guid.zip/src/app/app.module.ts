const routes: Routes = [
  { path: 'form', component: FormComponent },
  { path: 'display-form-data', component: DisplayFormDataComponent },
]


import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { FormComponent } from './FormComponent/form.component';
import { DisplayFormDataComponent } from './DisplayFormDataComponent/display.form.data.component';
import { RouterModule, Routes } from '@angular/router'

import { ContractService } from './contract.service';

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    DisplayFormDataComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ContractService],
  bootstrap: [AppComponent]
})
export class AppModule { }
