import { Guid } from 'guid-typescript'

export enum ContractStatusTypes { New, Counter, Saved, ReadyToSubmit, Submitted, Accepted, Rejected }
export class Contract {
  public id: Guid;
  public status: ContractStatusTypes;
  public firstName: string;
  public lastName: string;
  public price: string;
  // public depositAmount: string;
  // public depositType: string;
  // public allCash: string;
  // public loanAmount: string;
  // public financeType: string;
  // public intRate: string;
  // public allxash: string;
  // public financing: string;
  // public contingent: string;
  // public closeDate: string;
  // public closingCost: string;
  // public personalProperty: string;

  constructor() {
    this.id = Guid.create();
  }
}