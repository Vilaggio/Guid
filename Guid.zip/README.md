# reactive-form-test
A test with angular reactive forms and event emitters to pass form data around
